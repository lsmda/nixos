# Import plugin for Kimai

Import data features for Kimai.

## Changelog

All changes and compatible versions can be found in the [CHANGELOG](CHANGELOG.md).

## Installation

The installation is explained in the store page: https://www.kimai.org/store/keleo-importer-bundle.html

## Documentation

Available at: https://www.kimai.org/documentation/plugin-import.html

Read how to [import data from Kimai 1](https://www.kimai.org/documentation/migration-v1.html) (this is done via Command line).
